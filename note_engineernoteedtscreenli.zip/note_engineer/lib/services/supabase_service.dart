import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:pdf/widgets.dart' as pw;


class SupabaseService {
  final SupabaseClient _client;

  SupabaseService(String supabaseUrl, String supabaseKey)
      : _client = SupabaseClient('https://oxqjllupwzgebqvryyoq.supabase.co', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im94cWpsbHVwd3pnZWJxdnJ5eW9xIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MTYxNjkzNzQsImV4cCI6MjAzMTc0NTM3NH0.tWXn06Lsv_QlUNA2AiiA4UbH0ASgis5gZLfXdIhP6UQ');


  Future<PostgrestResponse> createNote(String userId, String title, String content) async {
    final response = await _client.from('notes').insert({
      'user_id': userId,
      'title': title,
      'content': content,
      'created_at': DateTime.now().toIso8601String(),
      'updated_at': DateTime.now().toIso8601String(),
      'is_favorite': false,
      'is_trashed': false,
    });
    return response;
  }

  Future<PostgrestResponse> updateNote(String noteId, String title, String content) async {
    final response = await _client.from('notes').update({
      'title': title,
      'content': content,
      'updated_at': DateTime.now().toIso8601String(),
    }).eq('id', noteId);
    return response;
  }

  Future<PostgrestResponse> deleteNote(String noteId) async {
    final response = await _client.from('notes').update({
      'is_trashed': true,
    }).eq('id', noteId);
    return response;
  }

  Future<List<Map<String, dynamic>>> getNotes(String userId) async {
    final response = await _client.from('notes').select('*').eq('user_id', userId).eq('is_trashed', false);
    return List<Map<String, dynamic>>.from(response);
  }

  Future<List<Map<String, dynamic>>> getFavoriteNotes(String userId) async {
    final response = await _client
        .from('notes')
        .select('*')
        .eq('user_id', userId)
        .eq('is_favorite', true)
        .eq('is_trashed', false);
    return List<Map<String, dynamic>>.from(response);
  }

  Future<PostgrestResponse> toggleFavorite(String noteId, bool isFavorite) async {
    final response = await _client.from('notes').update({
      'is_favorite': isFavorite,
    }).eq('id', noteId);
    return response;
  }

  Future<List<Map<String, dynamic>>> searchNotes(String userId, String query) async {
    final response = await _client.from('notes').select('*')
        .eq('user_id', userId)
        .eq('is_trashed', false)
        .or('title.ilike.%$query%,content.ilike.%$query%');
    return List<Map<String, dynamic>>.from(response);
  }
  List<Map<String, dynamic>> sortNotes(List<Map<String, dynamic>> notes, String sortType, bool isAscending) {
    if (sortType == 'created_at') {
      notes.sort((a, b) => isAscending
          ? a['created_at'].compareTo(b['created_at'])
          : b['created_at'].compareTo(a['created_at']));
    } else if (sortType == 'updated_at') {
      notes.sort((a, b) => isAscending
          ? a['updated_at'].compareTo(b['updated_at'])
          : b['updated_at'].compareTo(a['updated_at']));
    } else if (sortType == 'title') {
      notes.sort((a, b) => isAscending
          ? a['title'].compareTo(b['title'])
          : b['title'].compareTo(a['title']));
    }
    return notes;
  }
  Future<List<Map<String, dynamic>>> getDeletedNotes(String userId) async {
    final response = await _client
        .from('notes')
        .select('*')
        .eq('user_id', userId)
        .eq('is_trashed', true);
    return List<Map<String, dynamic>>.from(response);
  }

  Future<void> restoreNote(String noteId) async {
    await _client.from('notes').update({'is_trashed': false}).eq('id', noteId);
  }

  Future<void> permanentlyDeleteNote(String noteId) async {
    await _client.from('notes').delete().eq('id', noteId);
  }

  Future<void> restoreAllNotes(String userId) async {
    await _client.from('notes').update({'is_trashed': false}).eq('user_id', userId).eq('is_trashed', true);
  }

  Future<void> permanentlyDeleteAllNotes(String userId) async {
    await _client.from('notes').delete().eq('user_id', userId).eq('is_trashed', true);
  }
  Future<File> createPdf(String title, String content) async {
    final pdf = pw.Document();
    pdf.addPage(
      pw.Page(
        build: (pw.Context context) => pw.Center(
          child: pw.Column(
            children: [
              pw.Text(title, style: pw.TextStyle(fontSize: 24, fontWeight: pw.FontWeight.bold)),
              pw.SizedBox(height: 20),
              pw.Text(content),
            ],
          ),
        ),
      ),
    );

    final output = await getTemporaryDirectory();
    final file = File("${output.path}/note.pdf");
    await file.writeAsBytes(await pdf.save());
    return file;
  }
}