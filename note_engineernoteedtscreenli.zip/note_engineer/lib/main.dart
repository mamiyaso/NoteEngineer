import 'package:flutter/material.dart';
import 'package:note_engineer/screens/deleted_notes_screen.dart';
import 'package:note_engineer/screens/home_screen.dart';
import 'package:note_engineer/screens/note_edit_screen.dart';
import 'package:note_engineer/screens/settings_screen.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'screens/login_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Supabase.initialize(
    url: 'https://oxqjllupwzgebqvryyoq.supabase.co',
    anonKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im94cWpsbHVwd3pnZWJxdnJ5eW9xIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MTYxNjkzNzQsImV4cCI6MjAzMTc0NTM3NH0.tWXn06Lsv_QlUNA2AiiA4UbH0ASgis5gZLfXdIhP6UQ',
  );
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Note Engineer',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
    initialRoute: '/login',
    routes: {
      '/home': (context) => HomeScreen(),
      '/settings': (context) => SettingsScreen(),
      '/login': (context) => LoginScreen(),
      '/deleted_notes': (context) => DeletedNotesScreen(),
      '/note_edit': (context) => NoteEditScreen(onSave: (){} ),
    },
    );
  }
}
